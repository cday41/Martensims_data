namespace SEARCH
{
   public class RiskyForageModifier : Modifier
   {
		#region�Public�Members�(1)�

		#region�Constructors�(1)�

      public RiskyForageModifier()
      {
         base.Name = "RiskyForageModifier";
      }

		#endregion�Constructors�

		#endregion�Public�Members�
   }
}
