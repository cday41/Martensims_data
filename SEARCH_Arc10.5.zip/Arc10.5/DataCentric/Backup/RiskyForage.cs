namespace PAZ_Dispersal
{
   public class RiskyForageModifier : Modifier
   {
     
      public RiskyForageModifier()
      {
         base.Name = "RiskyForageModifier";
      }
     

   }
}
