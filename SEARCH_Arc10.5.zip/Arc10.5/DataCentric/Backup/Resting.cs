namespace PAZ_Dispersal
{
   public class Resting : BehaviourModifier
   {
   }
}
