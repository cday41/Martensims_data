namespace PAZ_Dispersal
{
   public class OutPutManage
   {
      public void WriteMap()
      {
      }
      public void WriteTextFile()
      {
      }
   }
}
