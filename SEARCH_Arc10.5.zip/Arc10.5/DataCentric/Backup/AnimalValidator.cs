namespace PAZ_Dispersal
{
   //public class AnimalValidator
   //{
   //   public void IsValid()
   //   {
   //   }
   //}


}
