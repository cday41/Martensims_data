namespace PAZ_Dispersal
{
   public class RiskySearchModifier : Modifier
   {
      public RiskySearchModifier()
      {
         base.Name = "RiskySearchModifier";
      }
      
   }
}
