namespace PAZ_Dispersal
{
   public class TemporalModifiers
   {
      public int bodyFatReduction;
      public int captureFood;
      public int moveSpeed;
      public int moveTurtosity;
      public int perceptonModifier;
      public int predationRisk;
   }
}
