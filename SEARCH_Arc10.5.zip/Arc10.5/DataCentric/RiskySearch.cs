namespace SEARCH
{
   public class RiskySearchModifier : Modifier
   {
		#region�Public�Members�(1)�

		#region�Constructors�(1)�

      public RiskySearchModifier()
      {
         base.Name = "RiskySearchModifier";
      }

		#endregion�Constructors�

		#endregion�Public�Members�
   }
}
