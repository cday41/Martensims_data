namespace SEARCH
{
   public class TemporalModifiers
   {
		#region�Public�Members�(6)�

		#region�Fields�(6)�

      public int bodyFatReduction;
      public int captureFood;
      public int moveSpeed;
      public int moveTurtosity;
      public int perceptonModifier;
      public int predationRisk;

		#endregion�Fields�

		#endregion�Public�Members�
   }
}
