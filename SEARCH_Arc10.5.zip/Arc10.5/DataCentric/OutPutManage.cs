namespace SEARCH
{
   public class OutPutManage
   {
		#region�Public�Members�(2)�

		#region�Methods�(2)�

      public void WriteMap()
      {
      }

      public void WriteTextFile()
      {
      }

		#endregion�Methods�

		#endregion�Public�Members�
   }
}
