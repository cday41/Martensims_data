namespace SEARCH
{
   //public class AnimalValidator
   //{
   //   public void IsValid()
   //   {
   //   }
   //}


}
