namespace SEARCH
{
   public class Resting : BehaviourModifier
   {

}
}
